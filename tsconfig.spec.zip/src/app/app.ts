
import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';


import { MsalProvder } from './msal-provder';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, MsalProvder],
  template: `
   <msal-provder>
  <router-outlet />
  </msal-provder>
  `,
})
export class AppComponent implements OnInit {
  ngOnInit(): void {

  }


}