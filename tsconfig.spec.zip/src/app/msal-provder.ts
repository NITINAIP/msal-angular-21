
import { Component, OnInit, inject } from '@angular/core';

import { MsalBroadcastService, MsalService } from '@azure/msal-angular';
import {
    AccountInfo,
    InteractionStatus
} from '@azure/msal-browser';

import { filter, take } from 'rxjs/operators';

@Component({
    selector: 'msal-provder',
    standalone: true,
    template: `
    @if(isAuthen) {
      <ng-content />
    }
  `,
})
export class MsalProvder implements OnInit {
    private msal = inject(MsalService);
    private msalBroadcast = inject(MsalBroadcastService);
    private scopes = ['openid', 'profile', 'email', 'User.Read'];
    public isAuthen = false
    ngOnInit(): void {
        this.msal.handleRedirectObservable().subscribe();

        this.msalBroadcast.inProgress$
            .pipe(
                filter((status) => status === InteractionStatus.None),
                take(1)
            )
            .subscribe(() => this.ensureAuthFlow());
    }

    private ensureAuthFlow(): void {
        const accounts = this.msal.instance.getAllAccounts();

        if (accounts.length === 0) {
            this.msal.loginRedirect(
                {
                    scopes: this.scopes,
                }
            );
            return;
        }

        const account = this.msal.instance.getActiveAccount() ?? accounts[0];
        this.msal.instance.setActiveAccount(account);
        this.fetchToken(account);
    }

    async fetchToken(account: AccountInfo) {
        try {
            const token = await this.msal.instance.acquireTokenSilent({
                account,
                scopes: this.scopes,
            })
            console.log(token);
            this.isAuthen = true;
        } catch (error) {
            console.log(error)
        }

    }
}