chmod +x setup-msal-standalone.sh

./setup-msal-standalone.sh \
  --client-id "YOUR_CLIENT_ID" \
  --tenant-id "YOUR_TENANT_ID" \
  --redirect-uri "http://localhost:4200/" \
  --post-logout-redirect-uri "http://localhost:4200/"