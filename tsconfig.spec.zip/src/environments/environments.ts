export const environment = {
  production: false,
  azureAd: {
    clientId: '',
    tenantId: '', 
    redirectUri: 'http://localhost:3000/',
    postLogoutRedirectUri: 'http://localhost:3000/',
  },
};
